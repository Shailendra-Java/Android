package com.example.shailendrathakur.checkconnection;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button checkButton;
    BroadcastReceiver broadcastReceiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkButton = (Button)findViewById(R.id.button1);
        checkButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                broadcastReceiver = null;
                checkConnectivity();

            }
        });
    }
    public void checkConnectivity()
    {
        broadcastReceiver = new BroadcastReceiver(){
            @Override
            public void onReceive(Context arg0, Intent arg1)
            {
                Bundle bundle = arg1.getExtras();
                //Extract mobile network related information as a network object from bundle
                NetworkInfo info = (NetworkInfo) bundle.getParcelable("networkInfo");

                //Retrieve Network state from networkinfo object
                NetworkInfo.State state = info.getState();

                //Check the state and display appropriate message
                if(state == state.CONNECTED)
                {
                    Toast.makeText(MainActivity.this, "Connected", Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "No Connectivity", Toast.LENGTH_LONG).show();
                }
            }
        };
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(broadcastReceiver, intentFilter);
    }
}
