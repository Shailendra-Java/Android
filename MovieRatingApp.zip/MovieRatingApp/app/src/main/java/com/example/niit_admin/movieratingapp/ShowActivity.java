package com.example.niit_admin.movieratingapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class ShowActivity extends Activity {

    TextView record;
    DatabaseOperations dbo;
    List<String> data;
    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(R.layout.show);

        record = (TextView)findViewById(R.id.rec);
        dbo = new DatabaseOperations(this);

        data = dbo.getReview();

        record.setText(data.toString());
    }
}
