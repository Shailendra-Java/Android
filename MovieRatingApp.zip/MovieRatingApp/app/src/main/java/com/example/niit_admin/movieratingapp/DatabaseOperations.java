package com.example.niit_admin.movieratingapp;

import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseOperations extends SQLiteOpenHelper {

    public DatabaseOperations(Context context)
    {
        super(context,"MovieRating.db",null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
       String table = "create table Rating(" +
               "ID integer primary key," +
               "Name text, Year text, Duration text," +
               "Rating text, Review text, Stars text," +
               "Director text)";
       sqLiteDatabase.execSQL(table);
    }

    public int addRecord(String n, String y, String d, float r, String rev, String s, String dir)
    {
        ContentValues contentValues = new ContentValues();
        contentValues.put("Name",n);
        contentValues.put("Year",y);
        contentValues.put("Duration",d);
        contentValues.put("Rating",r);
        contentValues.put("Review",rev);
        contentValues.put("Stars",s);
        contentValues.put("Director", dir);
        try {
            this.getWritableDatabase().insert("Rating", null, contentValues);
        }catch (Exception exp)
        {
            Log.e("Database error : ",exp.getMessage());
            return 0;
        }
        return 1;
    }
    public List<String> getReview()
    {
        List<String> record = new ArrayList<>();
        Cursor cursor = getReadableDatabase().query("Rating",null,null,null
        ,null,null,null,null);
        if(cursor.moveToFirst())
        {
            record.add(cursor.getString(1)+":"+cursor.getString(2)
            +":"+cursor.getString(3)+":"+cursor.getString(4)
            +":"+cursor.getString(5)+":"+cursor.getString(6)
            +":"+cursor.getString(7));
        }
        return record;
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
