package com.example.niit_admin.movieratingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText name, year, duration, review, stars, director;
    Button save, show;
    RatingBar rating;
    DatabaseOperations dbo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = (EditText)findViewById(R.id.mName);
        year = (EditText)findViewById(R.id.mYear);
        duration = (EditText)findViewById(R.id.mDuration);
        review = (EditText)findViewById(R.id.mRev);
        stars = (EditText)findViewById(R.id.mStar);
        director = (EditText)findViewById(R.id.mDir);

        save = (Button)findViewById(R.id.mSave);
        show = (Button)findViewById(R.id.mShow);
        rating = (RatingBar)findViewById(R.id.mRating);

        dbo = new DatabaseOperations(this);

        save.setOnClickListener(this);
        show.setOnClickListener(this);
    }
    public void onClick(View view)
    {
        String mName = name.getText().toString();
        String mYear = year.getText().toString();
        String mDur = duration.getText().toString();
        String mReview = review.getText().toString();
        String mStars = stars.getText().toString();
        String mDirector = director.getText().toString();
        float mRating = rating.getRating();

       if(view.getId()==R.id.mSave)
       {
           if(mName.equals("")||mYear.equals("")||mDur.equals("")
                   ||mReview.equals("")||mStars.equals("")||mDirector.equals("")
                   || mRating <= 0)
           {
               Toast.makeText(MainActivity.this,"Please fill all the fields",Toast.LENGTH_SHORT).show();
           }
           else
           {
                if(dbo.addRecord(mName,mYear,mDur,mRating,mReview,mStars,mDirector)>0)
                {
                    Toast.makeText(MainActivity.this,"Record Added",Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(MainActivity.this,"Insertion failed",Toast.LENGTH_SHORT).show();
           }
       }
       if(view.getId()==R.id.mShow)
       {
           Intent intent = new Intent(MainActivity.this,ShowActivity.class);
           startActivity(intent);
       }
    }
}
