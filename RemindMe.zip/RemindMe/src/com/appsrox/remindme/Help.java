package com.appsrox.remindme;

import android.app.Activity;
import android.os.Bundle;

public class Help extends Activity {

	public void onCreate(Bundle bdl)
	{
		super.onCreate(bdl);
		setContentView(R.layout.help);
	}
}
