package com.appsrox.remindme;

import android.app.Activity;

public class NeedDoctor extends Activity {

}
