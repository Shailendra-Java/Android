package com.niit.pocketdoctor;

import android.app.Activity;
import android.content.Intent;
import android.view.View.OnClickListener;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class Health extends Activity {

	private EditText age,height,weight;
	private RadioGroup rg;
	private RadioButton gender;
	private Button calc,reset;
	public void onCreate(Bundle bdl)
	{
		super.onCreate(bdl);
		setContentView(R.layout.health);
		
		age = (EditText)findViewById(R.id.age);
		height = (EditText)findViewById(R.id.height);
		weight = (EditText)findViewById(R.id.weight);
		rg = (RadioGroup)findViewById(R.id.radiogroup1);
		calc = (Button)findViewById(R.id.button1);
		reset = (Button)findViewById(R.id.button2);
		
		calc.setOnClickListener(new MyEvent());
		reset.setOnClickListener(new MyEvent());
	}
	private class MyEvent implements OnClickListener
	{
		@Override
		public void onClick(View view) {
			
			switch(view.getId())
			{
				case R.id.button1:
					int rId = rg.getCheckedRadioButtonId();
					String Age = age.getText().toString();
					String Height = height.getText().toString();
					String Weight = weight.getText().toString();
					Bundle bd = new Bundle();
					bd.putString("age", Age);
					bd.putString("height", Height);
					bd.putString("weight", Weight);
					Intent intent = new Intent(Health.this,HealthResult.class);
					intent.putExtras(bd);
					startActivity(intent);
					finish();
					break;
				case R.id.button2:
					age.setText("");
					height.setText("");
					weight.setText("");
					break;
			}
		}
	}
}
