package com.niit.pocketdoctor;

import java.util.Timer;
import java.util.TimerTask;

import com.niit.pocketdoctor.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

/**
 * @author NIIT
 *
 */
public class Welcome extends Activity {

	public void onCreate(Bundle b)
	{
		TextView tv;
		super.onCreate(b);
	       setContentView(R.layout.activity_main);
	       tv = (TextView)findViewById(R.id.textView1);	       
	       TimerTask task = new TimerTask() {

				@Override
				public void run() {

					// go to the main activity
					Intent nextActivity = new Intent(Welcome.this,
							Home.class);
					startActivity(nextActivity);

					// make sure splash screen activity is gone
					Welcome.this.finish();

				}

			};
			new Timer().schedule(task, 5000);
			// Font path
	        String fontPath = "fonts/IDroid Bold.otf";
	        Typeface tf = Typeface.createFromAsset(getAssets(), fontPath);
	        
	        // Applying font
	        tv.setTypeface(tf);
	}
}
