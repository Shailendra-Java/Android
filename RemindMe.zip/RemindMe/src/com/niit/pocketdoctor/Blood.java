package com.niit.pocketdoctor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Blood extends Activity {

	private EditText height,weight;
	private Button calc,reset;
	private RadioGroup rg;
	private RadioButton gender;
	public void onCreate(Bundle bdl)
	{
		super.onCreate(bdl);
		setContentView(R.layout.blood);
		height = (EditText)findViewById(R.id.height);
		weight = (EditText)findViewById(R.id.weight);
		rg = (RadioGroup)findViewById(R.id.radiogroup1);
		calc = (Button)findViewById(R.id.button1);
		reset = (Button)findViewById(R.id.button2);
		calc.setOnClickListener(new MyEvent());
		reset.setOnClickListener(new MyEvent());
	}
	private class MyEvent implements OnClickListener
	{
		@Override
		public void onClick(View view) {
			
			switch(view.getId())
			{
				case R.id.button1:
					String Height = height.getText().toString();
					String Weight = weight.getText().toString();
					String sex = ((RadioButton)findViewById(rg.getCheckedRadioButtonId())).getText().toString();
					Toast.makeText(Blood.this, sex, Toast.LENGTH_LONG).show();
					Bundle bd = new Bundle();
					bd.putString("height", Height);
					bd.putString("weight", Weight);
					bd.putString("sex", sex);
					Intent intent = new Intent(Blood.this,BloodResult.class);
					intent.putExtras(bd);
					startActivity(intent);
					finish();
					break;
				case R.id.button2:
					height.setText("");
					weight.setText("");
					break;
			}
		}
		}
}
