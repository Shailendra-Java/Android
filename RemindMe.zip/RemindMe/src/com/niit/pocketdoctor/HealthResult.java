package com.niit.pocketdoctor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class HealthResult extends Activity {

	TextView weight,measure;
	public void onCreate(Bundle bdl)
	{
		super.onCreate(bdl);
		setContentView(R.layout.health_result);
		
		weight = (TextView)findViewById(R.id.weight_mes);
		measure = (TextView)findViewById(R.id.bmi);
		calculate();
		
	}
	public void calculate()
	{
		double result;
		Intent intent = getIntent();
		Bundle bdl = intent.getExtras();
		double height = Double.parseDouble(bdl.getString("height"));
		double Weight = Double.parseDouble(bdl.getString("weight"));
		height /= 100; 
		
		result = Weight/(height*height);
		if(result <16)
			weight.setText("Extremely under weight");
		else if(result>=16 && result<=18.5)
			weight.setText("Under weight");
		else if(result>=18.6 && result<=25)
			weight.setText("Normal weight");
		else if(result>=25.1 && result<=30)
			weight.setText("Over weight");
		else if(result>=30.1 && result<=35)
			weight.setText("Obese class one");
		else if(result>=35.1 && result<=40)
			weight.setText("Obese class two");
		else
			weight.setText("Morbid Obese");
		double rounded = (double) Math.round(result * 100) / 100;
		measure.setText(""+rounded);
	}
}
