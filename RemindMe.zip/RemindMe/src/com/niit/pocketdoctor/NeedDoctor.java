package com.niit.pocketdoctor;

import com.niit.pocketdoctor.R;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
/**
 * @author NIIT
 *
 */
public class NeedDoctor extends Activity {

	Button find;
	EditText loc;
	Spinner type;
	private ArrayAdapter<String> mAdapter;
	BroadcastReceiver broadcastReciever=null;
	String[] doctor ={"-Select Doctor-","Allergist or Immunologist","Anesthesiologist"
			,"Cardiologist","Dermatologist","Gastroenterologist","Hematologist/Oncologist"
			,"Internal Medicine Physician","Nephrologist","Neurologist","Neurosurgeon"
			,"Obstetrician","Gynecologist","Nurse-Midwifery","Ophthalmologist","Orthopaedic Surgeon"
			,"Otolaryngologist","Pathologist","Pediatrician","Plastic Surgeon","Podiatrist"};
	boolean check;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.need_doctor);
		loc = (EditText)findViewById(R.id.location);
		type = (Spinner)findViewById(R.id.dr);
		find = (Button)findViewById(R.id.find);
		
		find.setOnClickListener(new MyEvent());
		mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,doctor);
		type.setAdapter(mAdapter);
	}
	class MyEvent implements OnClickListener
	{
		@Override
		public void onClick(View view)
		{
			String location = loc.getText().toString();
			String dr = type.getSelectedItem().toString();
			Intent intent = new Intent(NeedDoctor.this,WebSearch.class);
			Bundle bundle = new Bundle();
			bundle.putString("loc", location);
			bundle.putString("dr", dr);
			intent.putExtras(bundle);
			startActivity(intent);
		}
	}
}