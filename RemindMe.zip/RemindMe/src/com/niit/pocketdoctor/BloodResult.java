package com.niit.pocketdoctor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class BloodResult extends Activity {

	TextView blood;
	public void onCreate(Bundle bdl)
	{
		super.onCreate(bdl);
		setContentView(R.layout.blood_result);
		blood  = (TextView)findViewById(R.id.bmi);
		calculate();
	}
	public void calculate()
	{
		double result;
		Intent intent = getIntent();
		Bundle bdl = intent.getExtras();
		String gender = bdl.getString("sex");
		double height = Double.parseDouble(bdl.getString("height"));
		double Weight = Double.parseDouble(bdl.getString("weight"));
		height /= 100;
		if(gender.equals("Male"))
		{
			result = 0.3669*(height*height*height)+0.03219*Weight+0.6041;
		}
		else
		{
			result = 0.3561*(height*height*height)+0.03308*Weight+0.1833;
		}
		double rounded = (double) Math.round(result * 100) / 100;
		blood.setText(rounded+" ltr");
	}
}
