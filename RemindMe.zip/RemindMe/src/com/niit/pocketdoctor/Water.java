package com.niit.pocketdoctor;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class Water extends Activity {

	TextView watr;
	EditText weight,age;
	Button calc,reset;
	public void onCreate(Bundle bdl)
	{
		super.onCreate(bdl);
		setContentView(R.layout.water);
		
		watr = (TextView)findViewById(R.id.bmi);
		calc = (Button)findViewById(R.id.button1);
		reset = (Button)findViewById(R.id.button2);
		weight = (EditText)findViewById(R.id.weight);
		age = (EditText)findViewById(R.id.age);
		
		calc.setOnClickListener(new MyEvent());
		reset.setOnClickListener(new MyEvent());
	}
	private class MyEvent implements OnClickListener
	{
		@Override
		public void onClick(View view) {
			
			double result;
			switch(view.getId())
			{
				case R.id.button1:
					int ag = Integer.parseInt(age.getText().toString());
					double Weight = Double.parseDouble(weight.getText().toString());
					if(ag>=16 && ag<=30)
					{
						result = (38*Weight)/1000;
					}
					else if(ag>=31 && ag<=54)
					{
						result = (33*Weight)/1000;
					}
					else if(ag>=55 && ag<=65)
					{
						result = (30*Weight)/1000;
					}
					else
					{
						result = (25*Weight)/1000;
					}
					double round = (double) Math.round(result * 100) / 100;
					watr.setText(round+" ltr");
					break;
				case R.id.button2:
					age.setText("");
					watr.setText("");
					weight.setText("");
					break;
			}
		}
	}
}
