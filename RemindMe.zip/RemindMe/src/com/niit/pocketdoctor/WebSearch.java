package com.niit.pocketdoctor;
import com.niit.pocketdoctor.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.ProgressBar;

/**
 * @author NIIT
 *
 */
public class WebSearch extends Activity {

	WebView webView;
	ProgressBar pb;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.web_search);
		webView = (WebView)findViewById(R.id.wv);
		pb = (ProgressBar)findViewById(R.id.progressBar1);		
		webView.getSettings().setJavaScriptEnabled(true);
		webView.setWebViewClient(new WebViewClient());
		webView.loadUrl("http://www.google.com/search?q="+loadData());
	}
	public class WebViewClient extends android.webkit.WebViewClient
	{
		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			// TODO Auto-generated method stub
			super.onPageStarted(view, url, favicon);
		}
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			// TODO Auto-generated method stub
			view.loadUrl(url);
			return true;
		}
		@Override
		public void onPageFinished(WebView view, String url) {
			// TODO Auto-generated method stub
			super.onPageFinished(view, url);
			pb.setVisibility(view.GONE);
		}
	}
	
	public String loadData()
	{
		Intent intent = getIntent();
		Bundle bundle = intent.getExtras();
		String loc = bundle.getString("loc");
		String dr = bundle.getString("dr");
		
		return "Doctor of "+dr+" in "+loc;
	}
}
