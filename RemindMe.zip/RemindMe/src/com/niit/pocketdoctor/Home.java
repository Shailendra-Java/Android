package com.niit.pocketdoctor;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.niit.pocketdoctor.R;
import com.niit.pocketdoctor.model.DbHelper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.DigitalClock;
import android.widget.ImageButton;
import android.widget.TextView;
import android.view.View.OnClickListener;

/**
 * @author NIIT
 *
 */
public class Home extends Activity implements OnClickListener{

	ImageButton exit,add_r,setting,n_dr,help,remind,health,water,blood;
	TextView day,total;
	Date d;
	DigitalClock time;
	SimpleDateFormat sf,sdf;
	private DbHelper db;
	public void onCreate(Bundle b) 
	{
		super.onCreate(b);
		setContentView(R.layout.home);
		d = new Date();
		sf = new SimpleDateFormat("EEEE",Locale.ENGLISH);
		db = new DbHelper(this);
		int row = db.getCount();
		
		day = (TextView)findViewById(R.id.day);
		total = (TextView)findViewById(R.id.count);
		time = (DigitalClock)findViewById(R.id.time);
		exit = (ImageButton) findViewById(R.id.close);
		add_r = (ImageButton) findViewById(R.id.add);
		setting = (ImageButton) findViewById(R.id.pills);
		n_dr = (ImageButton) findViewById(R.id.n_dr);
		help = (ImageButton) findViewById(R.id.helpMe);
		remind = (ImageButton) findViewById(R.id.remind);
		health = (ImageButton)findViewById(R.id.health);
		blood = (ImageButton)findViewById(R.id.blood);
		water = (ImageButton)findViewById(R.id.water);
		
		day.setText(sf.format(d));
		total.setText(""+row);
		
		exit.setOnClickListener(this);
		add_r.setOnClickListener(this);
		setting.setOnClickListener(this);
		n_dr.setOnClickListener(this);
		help.setOnClickListener(this);
		remind.setOnClickListener(this);
		health.setOnClickListener(this);
		blood.setOnClickListener(this);
		water.setOnClickListener(this);
	}
	public void onClick(View view)
	{
		Intent in=null;
		switch(view.getId())
		{
			case R.id.close:
				AlertDialog.Builder newDialog = new AlertDialog.Builder(this);
				newDialog.setTitle("Confirm");
				newDialog.setMessage("Do you really want to close ?");
				newDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
				    public void onClick(DialogInterface dialog, int which){
				    	finish();
						System.exit(0);
				    }
				});
				newDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
				    public void onClick(DialogInterface dialog, int which){
				        dialog.cancel();
				    }
				});
				newDialog.show();
				
				break;
			case R.id.add:
				in = new Intent(Home.this,AddAlarmActivity.class);
				startActivity(in);
				break;
			case R.id.pills:
				in = new Intent(Home.this,SettingsActivity.class);
				startActivity(in);
				break;
			case R.id.n_dr:
				in = new Intent(Home.this,NeedDoctor.class);
				startActivity(in);
				break;
			case R.id.helpMe:
				in = new Intent(Home.this,Help.class);
				startActivity(in);
				break;
				
			case R.id.remind:
				in = new Intent(Home.this,MainActivity.class);
				startActivity(in);
				break;
			case R.id.health:
				in = new Intent(Home.this,Health.class);
				startActivity(in);
				break;
			case R.id.blood:
				in = new Intent(Home.this,Blood.class);
				startActivity(in);
				break;
			case R.id.water:
				in = new Intent(Home.this,Water.class);
				startActivity(in);
				break;
		}
	}

}
