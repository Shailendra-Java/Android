package com.example.shailendrathakur.androidmenus;

import android.app.Activity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    TextView contextMenu;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contextMenu = (TextView)findViewById(R.id.txt);
        btn = (Button)findViewById(R.id.todo);

        registerForContextMenu(contextMenu);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopup(btn);
            }
        });
    }

    public void showPopup(View view)
    {
        PopupMenu pop = new PopupMenu(this,view);
        getMenuInflater().inflate(R.menu.popup_menu,pop.getMenu());
        pop.show();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        getMenuInflater().inflate(R.menu.option_menu,menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        return super.onContextItemSelected(item);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.option_menu,menu);
        return  true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.edit:
                Toast.makeText(MainActivity.this,"Edit selected",Toast.LENGTH_LONG).show();
                break;
            case R.id.nw:
                Toast.makeText(MainActivity.this,"New selected",Toast.LENGTH_LONG).show();
                break;
            case R.id.opn:
                Toast.makeText(MainActivity.this,"Open selected",Toast.LENGTH_LONG).show();
                break;
            case R.id.save:
                Toast.makeText(MainActivity.this,"Save selected",Toast.LENGTH_LONG).show();
                break;
            case R.id.dlt:
                Toast.makeText(MainActivity.this,"Delete selected",Toast.LENGTH_LONG).show();
                break;
        }
        return true;
    }
}
