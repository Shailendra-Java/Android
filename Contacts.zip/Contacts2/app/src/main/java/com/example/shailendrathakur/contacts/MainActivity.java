package com.example.shailendrathakur.contacts;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    EditText name,mob;
    Button save,show;
    TextView title;
    private Typeface font;

    DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHandler(this);

        name = (EditText)findViewById(R.id.name);
        mob = (EditText)findViewById(R.id.mob);

        title = (TextView)findViewById(R.id._title);
        font = Typeface.createFromAsset(getAssets(), "fonts/28 Days Later.ttf");
        title.setTypeface(font);


        save = (Button)findViewById(R.id.save);
        show = (Button)findViewById(R.id.show);

        save.setOnClickListener(new ButtonEvent());
        show.setOnClickListener(new ButtonEvent());
    }

    public class ButtonEvent implements View.OnClickListener
    {
        @Override
        public void onClick(View view)
        {
            String _name = name.getText().toString();
            String _mob = mob.getText().toString();
            if(_name.equals(null) && _mob.equals(null)){
                Toast.makeText(MainActivity.this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
                return;
            }
            Contact ct = new Contact(_name,_mob);
            switch(view.getId())
            {
                case R.id.save:
                    db.addContact(new Contact(_name,_mob));
                    Toast.makeText(MainActivity.this, "Contact Saved", Toast.LENGTH_SHORT).show();
                    break;
                case R.id.show:
                    Intent intent = new Intent(MainActivity.this,ShowContact.class);
                    startActivity(intent);
                    break;
            }
        }
    }
}
