package com.example.shailendrathakur.contacts;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class ShowContact extends Activity {

    private static final int REQUEST_PHONE_CALL = 1;
    private static final int REQUEST_SEND_SMS = 2;
    ListView listView;
    ContactAdapter contactAdapter;
    DatabaseHandler databaseHandler;
    List<Contact> contactList;
    Intent intent;
    int pos;
    @Override
    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(R.layout.show_contacts);

        databaseHandler = new DatabaseHandler(this);
        contactList = databaseHandler.getAllContacts();

        listView = (ListView)findViewById(R.id.list);
        contactAdapter = new ContactAdapter(ShowContact.this,contactList);
        listView.setAdapter(contactAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                pos = i;
            }
        });
        registerForContextMenu(listView);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.contacts,menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Contact contact;
        switch(item.getItemId())
        {
            case R.id.del:
                contact = (Contact)contactList.get(pos);
                databaseHandler.deleteContact(contact);
                Toast.makeText(this, "Contact deleted successfully ", Toast.LENGTH_SHORT).show();
                break;

            case R.id.call:
                if (ContextCompat.checkSelfPermission(ShowContact.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(ShowContact.this, new String[]{Manifest.permission.CALL_PHONE},REQUEST_PHONE_CALL);
                }
                else {
                    makeCall();
                }

            case R.id.msg:
                if (ContextCompat.checkSelfPermission(ShowContact.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(ShowContact.this, new String[]{Manifest.permission.SEND_SMS},REQUEST_SEND_SMS);
                }
                else {
                    makeText();
                }
        }
        return true;
    }

    void makeCall(){
        Contact contact = (Contact)contactList.get(pos);
        intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+contact.getPhoneNumber()));
        startActivity(intent);
    }

    void makeText(){
        Toast.makeText(this, "Under construction", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQUEST_PHONE_CALL: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    makeCall();
                }
                else{

                }
                return;
            }

            case REQUEST_SEND_SMS:{
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    makeText();
                }
                else{

                }
                return;
            }
        }
    }
}
