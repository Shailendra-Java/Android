package com.example.drawhere;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Window;
import android.widget.TextView;

public class welcome extends Activity {

	private TextView tx,tx2,tx3;
	public void onCreate(Bundle b)
	{
		super.onCreate(b);
	       setContentView(R.layout.splash);
	       tx = (TextView)findViewById(R.id.textView1);
	       tx2 = (TextView)findViewById(R.id.textView2);
	       tx3 = (TextView)findViewById(R.id.textView3);
	       TimerTask task = new TimerTask() {

				@Override
				public void run() {

					// go to the main activity
					Intent nextActivity = new Intent(welcome.this,
							MainActivity.class);
					startActivity(nextActivity);

					// make sure splash screen activity is gone
					welcome.this.finish();

				}

			};
			new Timer().schedule(task, 6000);
			// Font path
	        String fontPath = "Fonts/28 Days Later.ttf";
	        Typeface tf = Typeface.createFromAsset(getAssets(), fontPath);
	        
	        // Applying font
	        tx.setTypeface(tf);
	     // Applying font
	        tx3.setTypeface(tf);
	        
	        String fontPath2 = "Fonts/Android Hollow.ttf";
	        Typeface tf2 = Typeface.createFromAsset(getAssets(), fontPath2);
	        
	        // Applying font
	        tx2.setTypeface(tf2);
	 
	}
}
