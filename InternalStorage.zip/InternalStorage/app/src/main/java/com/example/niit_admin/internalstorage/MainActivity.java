package com.example.niit_admin.internalstorage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {

    EditText notes;
    Button save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        notes = (EditText)findViewById(R.id.note);
        save = (Button)findViewById(R.id.save);
    }
    public void saveData(View view)
    {
        String fileName = "MyNotes.txt";
        String content = notes.getText().toString();
        try{
            FileOutputStream out = openFileOutput(fileName,MODE_PRIVATE);
            out.write(content.getBytes());
            out.close();
            Toast.makeText(MainActivity.this,"Record Saved",Toast.LENGTH_SHORT).show();
        }catch(Exception exp){
            Log.e("Exception :",exp.toString());
        }
    }
    public void showData(View view)
    {
        Intent intent = new Intent(MainActivity.this,ShowNotes.class);
        startActivity(intent);
    }
}
