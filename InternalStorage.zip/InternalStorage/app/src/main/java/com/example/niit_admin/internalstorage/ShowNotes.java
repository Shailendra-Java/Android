package com.example.niit_admin.internalstorage;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.io.FileInputStream;

public class ShowNotes extends Activity {

    TextView notes;
    @Override
    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(R.layout.show_notes);
        notes = (TextView)findViewById(R.id.note);
        readData();
    }
    public void readData()
    {
        String fileName = "MyNotes.txt";
        StringBuffer data = new StringBuffer();
        try{
            FileInputStream in = openFileInput(fileName);
            byte[] content = new byte[in.available()];
            in.read(content);
            for(int i=0; i<content.length; i++) {
                data.append((char) content[i]);
            }
            notes.setText(data.toString());
        }catch(Exception exp){
            Log.e("Exception :",exp.toString());
        }
    }
}
