package com.example.admin.notepad_app;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class activity2 extends AppCompatActivity {

    ListView lv;
    SqliteDatabaseHelper sqldb;
    ArrayList items;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2);
        lv = (ListView)findViewById(R.id.lView);
        sqldb = new SqliteDatabaseHelper(activity2.this);
        items = new ArrayList();
        List<Note> notes = sqldb.getAllNotes();
        for(Note n: notes) {
            items.add(n.getTitle());
            items.add(n.getNote());
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,items);
        lv.setAdapter(arrayAdapter);
    }

}
