package com.example.admin.notepad_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText title,note;
    Button add,view;
    SqliteDatabaseHelper sqldb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            title=(EditText)findViewById(R.id.title);
            note=(EditText)findViewById(R.id.note);

            add=(Button)findViewById(R.id.add);
            view=(Button)findViewById(R.id.view);

            add.setOnClickListener(new MyEvent());
            view.setOnClickListener(new MyEvent());
    }

    public class MyEvent implements View.OnClickListener{
        public void onClick(View v)
        {
            sqldb = new SqliteDatabaseHelper(MainActivity.this);
           switch(v.getId())
           {
               case R.id.add:
                   String t = title.getText().toString();
                   String n = note.getText().toString();
                   long x = sqldb.insertNote(t,n);
                   if(x>0) {
                       Toast.makeText(MainActivity.this, "Record Inserted", Toast.LENGTH_SHORT).show();
                       title.setText("");
                       note.setText("");
                   }
                   else
                       Toast.makeText(MainActivity.this, "Record Insertion failed!", Toast.LENGTH_SHORT).show();
                   break;
               case R.id.view:
                   Intent intent = new Intent(MainActivity.this,activity2.class);
                   startActivity(intent);
                   break;
           }
        }
    }

}
