package com.example.shailendrathakur.contacts;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class ContactAdapter extends BaseAdapter {

    private Activity activity;
    List<Contact> contactList;
    private static LayoutInflater inflater=null;

    public ContactAdapter(Activity a, List<Contact> contactList) {
        activity = a;
        this.contactList = contactList;
        inflater = (LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {return contactList.size();}

    public Object getItem(int position) {
        return contactList.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View vi=convertView;
        if(convertView==null)
            vi = inflater.inflate(R.layout.contacts, null);

        TextView title = (TextView)vi.findViewById(R.id.title); // title
        TextView mob = (TextView)vi.findViewById(R.id.mob); // Mobile No

        // Getting all values from listview
        for(Contact contact:contactList) {
            title.setText(contactList.get(position).getName());
            mob.setText(contactList.get(position).getPhoneNumber());
        }

        return vi;
    }
}
