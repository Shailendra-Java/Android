package com.example.shailendrathakur.contacts;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


public class ShowContact extends Activity {

    ListView listView;
    ContactAdapter contactAdapter;
    DatabaseHandler databaseHandler;
    List<Contact> contactList;
    @Override
    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(R.layout.show_contacts);

        databaseHandler = new DatabaseHandler(this);
        contactList = databaseHandler.getAllContacts();

        listView = (ListView)findViewById(R.id.list);
        contactAdapter = new ContactAdapter(ShowContact.this,contactList);
        listView.setAdapter(contactAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        });
    }

}
