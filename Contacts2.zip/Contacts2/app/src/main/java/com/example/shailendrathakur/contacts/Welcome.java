package com.example.shailendrathakur.contacts;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;


public class Welcome extends Activity {

    Typeface font;
    @Override
    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(R.layout.welcome);

        View v = findViewById(R.id.cont);
        TextView text =(TextView) findViewById(R.id.text);

        font = Typeface.createFromAsset(getAssets(), "fonts/28 Days Later.ttf");
        text.setTypeface(font);

        int durationMillis = 10000;

        RotateAnimation r = new RotateAnimation(0, 360,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        r.setDuration(durationMillis);
        r.setInterpolator(new LinearInterpolator());
        r.setRepeatMode(Animation.RESTART);
        r.setRepeatCount(Animation.INFINITE);
        text.startAnimation(r);

        RotateAnimation rC = new RotateAnimation(360, 0,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rC.setDuration(durationMillis);
        rC.setInterpolator(new LinearInterpolator());
        rC.setRepeatMode(Animation.RESTART);
        rC.setRepeatCount(Animation.INFINITE);
        v.startAnimation(rC);

        TimerTask task = new TimerTask() {

            @Override
            public void run() {

                // go to the main activity
                Intent nextActivity = new Intent(Welcome.this,
                        MainActivity.class);
                startActivity(nextActivity);

                // make sure splash screen activity is gone
                Welcome.this.finish();

            }

        };
        new Timer().schedule(task, 5000);
    }
}

