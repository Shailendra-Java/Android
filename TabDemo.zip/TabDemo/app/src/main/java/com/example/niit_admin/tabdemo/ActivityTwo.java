package com.example.niit_admin.tabdemo;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by NIIT_ADMIN on 5/25/2018.
 */

public class ActivityTwo extends Activity {

    @Override
    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(R.layout.digital);
    }

}
