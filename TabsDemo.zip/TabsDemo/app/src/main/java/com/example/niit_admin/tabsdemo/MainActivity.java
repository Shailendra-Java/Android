package com.example.niit_admin.tabsdemo;

import android.app.TabActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TabHost;

public class MainActivity extends TabActivity {

    TabHost tabHost;
    TabHost.TabSpec spec1, spec2;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tabHost = (TabHost)findViewById(android.R.id.tabhost);
        tabHost.setup();

        setTabs();
    }
    public void setTabs()
    {
        spec1 = tabHost.newTabSpec("Tab 1");
        spec2 = tabHost.newTabSpec("Tab 2");

        spec1.setIndicator("Login",getResources().getDrawable(R.drawable.ic_launcher_background));
        intent = new Intent(this,Login.class);
        spec1.setContent(intent);

        spec2.setIndicator("Register",getResources().getDrawable(R.drawable.ic_launcher_background));
        intent = new Intent(this,Register.class);
        spec2.setContent(intent);

        tabHost.addTab(spec1);
        tabHost.addTab(spec2);
    }
}
